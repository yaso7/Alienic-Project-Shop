import type { Metadata } from "next"
import Image from "next/image"

export const metadata: Metadata = {
  title: "Projects",
  description:
    "Explore the sacred collections of The Alienic Project — each altar a testament to dark artistry.",
}

const projects = [
  {
    title: "Oxidized Relics",
    date: "Collection I — 2024",
    mood: ["Ancient", "Weathered", "Sacred"],
    description:
      "The first collection drew from the beauty of decay — silver pieces intentionally aged to carry the weight of time. Each relic bears the marks of a deliberate transformation, as if unearthed from a forgotten shrine.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PFP-Black-PrwFTaDbWXZr9S6Y5KiouNx5x0YhKZ.png",
  },
  {
    title: "Void Geometry",
    date: "Collection II — 2024",
    mood: ["Futuristic", "Minimal", "Dark"],
    description:
      "Where sharp angles meet organic curves. This collection explores the tension between precision and chaos — geometric forms that seem to fold in on themselves, creating portals to the void.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/SC-%20Concept.1-Ee32igpxofdLPJjer1kWRmZ1zKmkV3.png",
  },
  {
    title: "Matte Shadows",
    date: "Collection III — 2025",
    mood: ["Mysterious", "Tactile", "Heavy"],
    description:
      "An exploration of darkness itself. Black-on-black textured metalwork that absorbs light and demands touch. These pieces exist in the space between visibility and void — shadow made solid.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PFP-White-Yab1gmXrg4upN6ybuve3oAVG39odZF.png",
  },
  {
    title: "Stellar Fragments",
    date: "Collection IV — 2025",
    mood: ["Cosmic", "Raw", "Luminous"],
    description:
      "Inspired by the remnants of collapsed stars. Each piece in this collection captures the paradox of cosmic violence and beauty — raw metal surfaces that catch light like distant nebulae.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Business%20Card-Front-m3BoQOivskc8izgiDAkRwaU9IqcqJB.png",
  },
]

export default function ProjectsPage() {
  return (
    <div className="min-h-screen pt-24">
      {/* Header */}
      <section className="py-24 md:py-32 px-6 noise-bg text-center">
        <h2 className="text-xs uppercase tracking-[0.3em] text-primary mb-4">
          The Archive
        </h2>
        <h1 className="font-[var(--font-fraktur)] text-4xl md:text-6xl text-foreground mb-6">
          Sacred Collections
        </h1>
        <div className="gothic-divider w-48 mx-auto mb-6" />
        <p className="max-w-lg mx-auto text-base text-muted-foreground leading-relaxed">
          Each collection is an altar — a curated body of work unified by
          mood, material, and meaning. Enter and bear witness.
        </p>
      </section>

      {/* Projects */}
      <section className="py-12 px-6">
        <div className="mx-auto max-w-6xl flex flex-col gap-24">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className={`grid grid-cols-1 md:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? "md:direction-rtl" : ""
              }`}
            >
              <div
                className={`relative aspect-[4/3] overflow-hidden group ${
                  index % 2 === 1 ? "md:order-2" : ""
                }`}
              >
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/50 to-transparent" />
              </div>

              <div
                className={`flex flex-col gap-4 ${
                  index % 2 === 1 ? "md:order-1 md:text-right md:items-end" : ""
                }`}
              >
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  {project.date}
                </p>
                <h3 className="font-[var(--font-fraktur)] text-3xl md:text-4xl text-foreground">
                  {project.title}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {project.mood.map((keyword) => (
                    <span
                      key={keyword}
                      className="text-xs uppercase tracking-[0.2em] text-primary border border-border px-3 py-1"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
                <div className={`gothic-divider w-24 ${index % 2 === 1 ? "md:self-end" : ""}`} />
                <p className="text-base text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32 px-6 bg-secondary text-center">
        <p className="font-[var(--font-fraktur)] text-2xl md:text-3xl text-foreground mb-4">
          Ready to claim your piece?
        </p>
        <p className="text-sm text-muted-foreground mb-8">
          Visit the shop or reach out for custom commissions.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="/shop"
            className="px-8 py-3 bg-primary text-primary-foreground text-sm uppercase tracking-[0.2em] hover:bg-primary/90 transition-all duration-300"
          >
            Enter the Shop
          </a>
          <a
            href="/contact"
            className="px-8 py-3 border border-border text-foreground text-sm uppercase tracking-[0.2em] hover:bg-accent transition-all duration-300"
          >
            Commission a Piece
          </a>
        </div>
      </section>
    </div>
  )
}
