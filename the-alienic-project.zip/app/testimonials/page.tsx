import type { Metadata } from "next"
import { Star } from "lucide-react"
import { ReviewForm } from "@/components/testimonials/review-form"

export const metadata: Metadata = {
  title: "Testimonials",
  description:
    "Read confessionals from those who carry Alienic pieces — and share your own tale.",
}

const testimonials = [
  {
    name: "Mara V.",
    location: "Berlin, Germany",
    rating: 5,
    text: "The piece arrived wrapped in black tissue like a relic from another world. It carries a weight that goes beyond the physical \u2014 you can feel the intention in every curve and edge.",
    product: "The Void Pendant",
  },
  {
    name: "Kai S.",
    location: "Portland, USA",
    rating: 5,
    text: "I\u2019ve never owned anything that felt so deliberately crafted. The oxidation gives it this living quality, like it\u2019s still transforming. Absolutely transcendent work.",
    product: "Chain of Whispers",
  },
  {
    name: "Lena R.",
    location: "Stockholm, Sweden",
    rating: 5,
    text: "More than jewelry \u2014 it\u2019s a conversation piece that speaks without words. Strangers stop me to ask about it. It feels like wearing a secret.",
    product: "Stellar Fragment Ring",
  },
  {
    name: "Dmitri K.",
    location: "Moscow, Russia",
    rating: 4,
    text: "The craftsmanship is undeniable. Each surface tells a story of the hands that shaped it. This is what happens when art refuses to be mass-produced.",
    product: "The Beacon",
  },
  {
    name: "Anya T.",
    location: "Tokyo, Japan",
    rating: 5,
    text: "I commissioned a custom piece and the entire process felt sacred \u2014 from the initial conversation to the moment I unwrapped it. It\u2019s become my most treasured possession.",
    product: "Custom Commission",
  },
  {
    name: "Sol M.",
    location: "Buenos Aires, Argentina",
    rating: 5,
    text: "The Relic of the Fallen Star is extraordinary. Knowing there\u2019s actual meteorite in the piece makes it feel like I\u2019m carrying a fragment of the universe. Incomparable artistry.",
    product: "Relic of the Fallen Star",
  },
]

export default function TestimonialsPage() {
  return (
    <div className="min-h-screen pt-24">
      {/* Header */}
      <section className="py-24 md:py-32 px-6 noise-bg text-center">
        <h2 className="text-xs uppercase tracking-[0.3em] text-primary mb-4">
          The Confessional
        </h2>
        <h1 className="font-[var(--font-fraktur)] text-4xl md:text-6xl text-foreground mb-6">
          Voices in the Dark
        </h1>
        <div className="gothic-divider w-48 mx-auto mb-6" />
        <p className="max-w-lg mx-auto text-base text-muted-foreground leading-relaxed">
          Those who carry an Alienic piece carry a story. Here, they share
          their confessionals.
        </p>
      </section>

      {/* Testimonials */}
      <section className="py-12 px-6 bg-secondary">
        <div className="mx-auto max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="flex flex-col gap-4 p-8 bg-card border border-border hover:border-primary/20 transition-all duration-500"
            >
              <div className="flex gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={
                      i < testimonial.rating
                        ? "fill-primary text-primary"
                        : "text-border"
                    }
                  />
                ))}
              </div>

              <blockquote className="text-base text-muted-foreground leading-relaxed italic">
                {`"${testimonial.text}"`}
              </blockquote>

              <div className="gothic-divider w-full" />

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-foreground font-medium">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.location}
                  </p>
                </div>
                <p className="text-xs uppercase tracking-[0.2em] text-primary">
                  {testimonial.product}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Submit a Review */}
      <section className="py-24 md:py-32 px-6 noise-bg">
        <div className="mx-auto max-w-2xl text-center mb-12">
          <h2 className="text-xs uppercase tracking-[0.3em] text-primary mb-4">
            Share Your Tale
          </h2>
          <p className="font-[var(--font-fraktur)] text-3xl md:text-4xl text-foreground mb-4">
            Leave a Confessional
          </p>
          <p className="text-sm text-muted-foreground">
            Your voice joins the chorus of those who have been touched by
            these creations.
          </p>
        </div>
        <ReviewForm />
      </section>
    </div>
  )
}
