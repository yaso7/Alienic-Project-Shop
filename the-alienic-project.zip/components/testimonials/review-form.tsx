"use client"

import { useState } from "react"
import { Star } from "lucide-react"

export function ReviewForm() {
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [submitted, setSubmitted] = useState(false)

  if (submitted) {
    return (
      <div className="mx-auto max-w-2xl text-center py-12">
        <p className="font-[var(--font-fraktur)] text-2xl text-foreground mb-4">
          Your words have been received
        </p>
        <p className="text-sm text-muted-foreground">
          Like an inscription on ancient stone, your confessional shall
          endure. We are grateful.
        </p>
      </div>
    )
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault()
        setSubmitted(true)
      }}
      className="mx-auto max-w-2xl flex flex-col gap-6"
    >
      {/* Star Rating */}
      <div className="flex flex-col items-center gap-2">
        <label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Your Rating
        </label>
        <div className="flex gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setRating(i + 1)}
              onMouseEnter={() => setHoverRating(i + 1)}
              onMouseLeave={() => setHoverRating(0)}
              aria-label={`Rate ${i + 1} stars`}
            >
              <Star
                size={24}
                className={
                  i < (hoverRating || rating)
                    ? "fill-primary text-primary transition-colors"
                    : "text-border transition-colors"
                }
              />
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex flex-col gap-2">
          <label
            htmlFor="name"
            className="text-xs uppercase tracking-[0.2em] text-muted-foreground"
          >
            Your Name
          </label>
          <input
            id="name"
            type="text"
            required
            placeholder="Enter your name"
            className="bg-input border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none transition-colors"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label
            htmlFor="location"
            className="text-xs uppercase tracking-[0.2em] text-muted-foreground"
          >
            Location
          </label>
          <input
            id="location"
            type="text"
            placeholder="City, Country"
            className="bg-input border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none transition-colors"
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label
          htmlFor="product"
          className="text-xs uppercase tracking-[0.2em] text-muted-foreground"
        >
          Piece Acquired
        </label>
        <input
          id="product"
          type="text"
          placeholder="Which piece do you carry?"
          className="bg-input border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none transition-colors"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label
          htmlFor="review"
          className="text-xs uppercase tracking-[0.2em] text-muted-foreground"
        >
          Your Confessional
        </label>
        <textarea
          id="review"
          required
          rows={5}
          placeholder="Share your experience with the piece..."
          className="bg-input border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none transition-colors resize-none"
        />
      </div>

      <button
        type="submit"
        className="self-center px-8 py-3 bg-primary text-primary-foreground text-sm uppercase tracking-[0.2em] hover:bg-primary/90 transition-all duration-300"
      >
        Submit Confessional
      </button>
    </form>
  )
}
