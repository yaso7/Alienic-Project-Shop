"use client"

import Image from "next/image"
import { useState } from "react"
import { X, Instagram } from "lucide-react"

const categories = ["All", "Pendants", "Rings", "Chains", "One-of-One"]

const products = [
  {
    id: 1,
    name: "The Void Pendant",
    category: "Pendants",
    price: "$85",
    material: "Oxidized Sterling Silver",
    collection: "Oxidized Relics",
    story:
      "Born from the silence between stars. This pendant captures the gravitational pull of absence — a void that draws the eye and holds the spirit. Handforged and darkened through controlled oxidation.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PFP-Black-PrwFTaDbWXZr9S6Y5KiouNx5x0YhKZ.png",
  },
  {
    id: 2,
    name: "Stellar Fragment Ring",
    category: "Rings",
    price: "$120",
    material: "Matte Black Steel",
    collection: "Void Geometry",
    story:
      "A fractured piece of cosmic geometry, wrapped around your finger like a promise from another dimension. The angular surfaces catch light in unexpected ways, shifting between shadow and shine.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/SC-%20Concept.1-Ee32igpxofdLPJjer1kWRmZ1zKmkV3.png",
  },
  {
    id: 3,
    name: "The Beacon",
    category: "Pendants",
    price: "$95",
    material: "Brushed Silver, Black Cord",
    collection: "Matte Shadows",
    story:
      "A four-pointed star that serves as a guide through the darkness. The beacon pendant is both compass and talisman — a reminder that light persists even in the deepest void.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PFP-White-Yab1gmXrg4upN6ybuve3oAVG39odZF.png",
  },
  {
    id: 4,
    name: "Chain of Whispers",
    category: "Chains",
    price: "$65",
    material: "Oxidized Silver Links",
    collection: "Oxidized Relics",
    story:
      "Each link forged separately, carrying its own imperfections like whispered secrets. This chain is designed to age with you, growing darker and more characterful with wear.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Business%20Card-Front-m3BoQOivskc8izgiDAkRwaU9IqcqJB.png",
  },
  {
    id: 5,
    name: "Relic of the Fallen Star",
    category: "One-of-One",
    price: "$250",
    material: "Mixed Metals, Meteorite Fragment",
    collection: "Stellar Fragments",
    story:
      "The crown jewel of the collection. A mixed-metal sculpture pendant incorporating a genuine meteorite fragment — a piece of the cosmos you can carry. Utterly unique, never to be replicated.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1.Sticker-%20Logo-zkFcGsmctG92tbpbE9EKeUL5Jrkz5d.png",
  },
  {
    id: 6,
    name: "Obsidian Band",
    category: "Rings",
    price: "$90",
    material: "Matte Black Titanium",
    collection: "Matte Shadows",
    story:
      "A ring that absorbs light. The matte black titanium surface is treated to resist fingerprints and shine, creating a permanent shadow that wraps your finger in darkness.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PFP-Black-PrwFTaDbWXZr9S6Y5KiouNx5x0YhKZ.png",
  },
]

interface Product {
  id: number
  name: string
  category: string
  price: string
  material: string
  collection: string
  story: string
  image: string
}

function ProductModal({
  product,
  onClose,
}: {
  product: Product
  onClose: () => void
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/90 backdrop-blur-sm">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-card border border-border">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Close"
        >
          <X size={24} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative aspect-square">
            <Image
              src={product.image}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>

          <div className="flex flex-col gap-4 p-8">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              {product.collection}
            </p>
            <h2 className="font-[var(--font-fraktur)] text-3xl text-foreground">
              {product.name}
            </h2>
            <p className="text-2xl text-primary">{product.price}</p>
            <div className="gothic-divider w-full" />

            <div className="flex flex-col gap-1">
              <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                Material
              </p>
              <p className="text-sm text-foreground">{product.material}</p>
            </div>

            <div className="flex flex-col gap-1">
              <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                The Tale
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {product.story}
              </p>
            </div>

            <div className="gothic-divider w-full" />

            <p className="text-xs text-muted-foreground italic">
              To acquire this piece, reach out via Instagram or Telegram.
              Each transaction is personal and handled with care.
            </p>

            <div className="flex flex-col gap-2 mt-2">
              <a
                href="https://instagram.com/alienicproject"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-sm uppercase tracking-[0.2em] hover:bg-primary/90 transition-all duration-300"
              >
                <Instagram size={16} />
                Inquire on Instagram
              </a>
              <a
                href="https://t.me/alienicproject"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-6 py-3 border border-border text-foreground text-sm uppercase tracking-[0.2em] hover:bg-accent transition-all duration-300"
              >
                Inquire on Telegram
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export function ShopGrid() {
  const [activeCategory, setActiveCategory] = useState("All")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  const filteredProducts =
    activeCategory === "All"
      ? products
      : products.filter((p) => p.category === activeCategory)

  return (
    <>
      {/* Filters */}
      <section className="py-8 px-6 border-b border-border">
        <div className="mx-auto max-w-6xl flex flex-wrap justify-center gap-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-xs uppercase tracking-[0.2em] px-4 py-2 transition-all duration-300 ${
                activeCategory === cat
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground border border-border"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Product Grid */}
      <section className="py-12 px-6 bg-secondary">
        <div className="mx-auto max-w-6xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <button
              key={product.id}
              onClick={() => setSelectedProduct(product)}
              className="group text-left bg-card border border-border hover:border-primary/30 transition-all duration-500"
            >
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent opacity-60" />
              </div>
              <div className="p-4 flex flex-col gap-1">
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  {product.collection}
                </p>
                <h3 className="font-[var(--font-fraktur)] text-xl text-foreground group-hover:text-primary transition-colors duration-300">
                  {product.name}
                </h3>
                <p className="text-sm text-primary">{product.price}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {product.material}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Modal */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </>
  )
}
